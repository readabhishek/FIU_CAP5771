import json
import sys

query = []
data = json.load(open('Keywords.json'))

keywords = data["Amex"]["keys"].split(",")
for keys in keywords:
    query.append(keys.strip(' \t\n\r'))
for keys in query:
    print(keys)


def some_func():
    print('in test 1, unproductive')
if __name__ == '__main__':
    print("Inside other file")
    some_func()
    # test1.py executed as script
    # do something

